package com.bean.demo.exception;

public class AdminIDNotFoundException extends Exception {

	public AdminIDNotFoundException(String message) {
		super(message);
	}

}
