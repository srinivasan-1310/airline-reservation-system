package com.bean.demo.exception;

public class BookingIdNotFoundException extends Exception{
	public BookingIdNotFoundException(String message) {
		super(message);
	}

}
