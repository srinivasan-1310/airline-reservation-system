package com.bean.demo.exception;

public class FlightDataAlreadyAvailableFoundException extends Exception{

	public FlightDataAlreadyAvailableFoundException(String message) {
		super(message);
	}

}
