package com.bean.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirwaysApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirwaysApplication.class, args);
	}

}
