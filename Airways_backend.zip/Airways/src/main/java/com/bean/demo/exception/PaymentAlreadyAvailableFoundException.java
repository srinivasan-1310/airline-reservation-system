package com.bean.demo.exception;

public class PaymentAlreadyAvailableFoundException extends Exception{
	public PaymentAlreadyAvailableFoundException(String message) {
		super(message);
	}


}
