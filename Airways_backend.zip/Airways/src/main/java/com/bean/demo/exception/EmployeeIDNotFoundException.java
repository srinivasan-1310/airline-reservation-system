package com.bean.demo.exception;

public class EmployeeIDNotFoundException extends Exception {

	public EmployeeIDNotFoundException(String message) {
		super(message);
	}

}
